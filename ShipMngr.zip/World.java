package project1;
/*
 * World.java
 * 4/27/19
 * Brandon Tennyson
 * 
 *  this is the world class and it holds all the objects unless  we are dealing with multiple worlds with more seaports etc
 *  this class takes in the txt files and creates the obects that are menat to be created based on the format of the text file
 *  this class also has some neat freatures that allow for searching and sorting
 *  
 *  
 */
import java.awt.BorderLayout;
import java.awt.GridLayout;

/*
 * World.java
 * 3/30/19
 * Brandon Tennyson
 * 
 *this is the world class and it extends thing because guess what?
 *the world is a thing too! 
 *anyways world is the next biggest thing because it hold all other 
 *objects because all of these things are in the world.
 *it sorts through each thing and make sure that it is created and recorded
 *so that it may be searched or used
 * 
 */

import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JPanel;

final class World extends Thing {

	HashMap<Integer, SeaPort> seaPorts;

//default constructor
	public World() {

		super();

	}

//scanner constructor
	public World(Scanner in) {
		super(in);
	}

//this method is the heart of this class because it takes in all values and sorts them into different places where they are suppost to go
	@SuppressWarnings("resource")
	public void process(String s) {

		seaPorts = new HashMap<Integer, SeaPort>();
		HashMap<Integer, Dock> docks = new HashMap<>();
		HashMap<Integer, Ship> ships = new HashMap<>();

		Scanner in = new Scanner(s);

		while (in.hasNextLine()) {
			if (!in.hasNext()) {
				return;
			}

			if (in.hasNext()) {
				switch (in.next()) {
				case "port":
					SeaPort port = new SeaPort(in);
					seaPorts.put(port.getIndex(), port);
					break;
				case "dock":
					Dock dock = new Dock(in);
					docks.put(dock.getIndex(), dock);
					dock.dockParent(seaPorts);
					seaPorts.get(dock.getParent()).getDocks().add(dock);
					break;
				case "pship":
					PassengerShip pShip = new PassengerShip(in);
					ships.put(pShip.getIndex(), pShip);
					addShipToParent(pShip, seaPorts);
					break;
				case "cship":
					CargoShip cShip = new CargoShip(in);
					ships.put(cShip.getIndex(), cShip);
					addShipToParent(cShip, seaPorts);
					break;
				case "person":
					Person person = new Person(in);
					seaPorts.get(person.getParent()).getPersons().add(person);
					break;
				case "job":
					Job newJob = new Job(in, jobs, ships);
					addPanel(newJob.getPanel());
					addJobToShip(newJob, ships, docks);
					break;

				}
			}
		}
	}
//these add methods are different and are purposed to add the instances to their parent 

	private void addJobToShip(Job j, HashMap<Integer, Ship> ships, HashMap<Integer, Dock> docks) {
		// TODO Auto-generated method stub
		Dock d;
		Ship s = ships.get(j.getParent());
		if (s != null) {
			s.getJobs().add(j);
		} else {
			d = docks.get(j.getParent());
			d.getShip().getJobs().add(j);
		}
	}

	JPanel jobs;
	JPanel allJobs = new JPanel();
	JFrame frame2 = new JFrame();
	int count = 0;

	void setPanel(JPanel jobs) {
		count++;
		this.jobs = jobs;
	}

	void addPanel(JPanel panel) {
		allJobs.setLayout(new GridLayout(1, count));
		allJobs.add(panel, BorderLayout.SOUTH);
	}

	void showFrame() {

		frame2.setSize(210, 800);// size of window
		frame2.setVisible(true);

		frame2.add(allJobs);

	}
	void addShipToParent(Ship ms, HashMap<Integer, SeaPort> seaPorts) {

		int shipParent = ms.getParent();
		SeaPort currentSeaPort = null;
		for (SeaPort sp : seaPorts.values()) { // this whole mess is to find the correct dock for the ship
			for (Dock d : sp.getDocks()) {
				if (d.getIndex() == shipParent)
					;
				currentSeaPort = sp;
			}
		}
		if (currentSeaPort.getIndex() == shipParent) {
			currentSeaPort.getShips().add(ms);
			currentSeaPort.getQueue().add(ms);
			return;
		}
		for (Dock d : currentSeaPort.getDocks()) {// this is a second loop that will put the ships in their correct
													// docks
			if (d.getIndex() == shipParent) {
				d.setShip(ms);
			}
		}
		currentSeaPort.getShips().add(ms);

	}

	public Ship getShipByIndex(int x, HashMap<Integer, Ship> hms) {
		return hms.get(x);
	}

//these are the search methods that are used by the gui action listener
	public String searchIndex(int x) {
		String s = null;
		for (SeaPort sp : seaPorts.values()) {
			for (Person p : sp.getPersons()) {
				if (p.getIndex() == x)
					s += p.toString();
			}
			for (Dock d : sp.getDocks()) {
				if (d.getIndex() == x)
					s += d.toString();
			}
			for (Ship sh : sp.getShips()) {
				if (sh.getIndex() == x)
					s += sh.toString();
			}
			if (sp.getIndex() == x) {
				s += sp.toString();
			}
		}
		return s;
	}

	public String searchSkill(String text) {
		String s = null;
		for (SeaPort sp : seaPorts.values())
			for (Person p : sp.persons)
				if (p.getSkill().equalsIgnoreCase(text))
					s += p.toString();

		return s;
	}

	public String searchName(String text) {
		String s = null;
		for (SeaPort sp : seaPorts.values()) {
			for (Person p : sp.getPersons()) {
				if (p.getName().equalsIgnoreCase(text))
					s += p.toString();
			}
			for (Dock d : sp.getDocks()) {
				if (d.getName().equalsIgnoreCase(text))
					s += d.toString();
			}
			for (Ship sh : sp.getShips()) {
				if (sh.getName().equalsIgnoreCase(text))
					s += sh.toString();
			}
			if (sp.getName().equalsIgnoreCase(text)) {
				s += sp.toString();
			}
		}
		return s;
	}

//below are the sorting methods and they ise the arraylist that is located in the seaport class and uses the values within the values in the array list to determine what is larger in value
	public String sortWeight() {
		String st = "";

		for (SeaPort sp : seaPorts.values()) {
			if (sp.isExist()) {
				sp.sortByWeight();
				st += "Port: \n ";
				st += sp.getName() + " Ships:\n    ";

				for (Ship s : sp.getQueue()) {
					st += s.getName() + ": " + s.getWeight() + "\n    ";
				}
				st += "\n";
			}
		}
		return st;
	}

	public String sortLength() {
		String st = "";

		for (SeaPort sp : seaPorts.values()) {
			if (sp.isExist()) {

				sp.sortByLength();
				st += "Port: \n ";
				st += sp.getName() + " Ships:\n    ";

				for (Ship s : sp.getQueue()) {
					st += s.getName() + ": " + s.getLength() + "\n    ";
				}
				st += "\n";
			}
		}
		return st;
	}

	public String sortWidth() {
		String st = "";

		for (SeaPort sp : seaPorts.values()) {
			if (sp.isExist()) {

				sp.sortByWidth();
				st += "Port: \n ";
				st += sp.getName() + " Ships:\n    ";

				for (Ship s : sp.getQueue()) {
					st += s.getName() + ": " + s.getWidth() + "\n    ";
				}
				st += "\n";
			}
		}
		return st;
	}

	public String sortDraft() {
		String st = "";

		for (SeaPort sp : seaPorts.values()) {
			if (sp.isExist()) {

				sp.sortByDraft();
				st += "Port: \n ";
				st += sp.getName() + "Ships:\n    ";

				for (Ship s : sp.getQueue()) {
					st += s.getName() + ": " + s.getDraft() + "\n    ";
				}
				st += "\n";
			}
		}
		return st;
	}
//----------end search methods----------^

	public String toString() {// does what toString methods do...
		String s = ">>>>>The world: ";

		for (SeaPort seaPort : seaPorts.values()) {

			s += seaPort.toString() + "\n";

		}
		return s;
	}

}
