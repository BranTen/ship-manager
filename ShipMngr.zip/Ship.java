package project1;

import java.util.ArrayList;
/*
 * Ship.java
 * 4/27/19
 * Brandon Tennyson
 * 
 *This is the ship class where is is parent
 *to cargo ship and passenger ship
 *
 *this class also holds its specific job that needs to be done 
 * 
 */import java.util.Scanner;

public class Ship extends Thing{

PortTime arrivalTime = new PortTime();
PortTime dockTime = new PortTime();
double draft;
double length;
double weight;
double width;
Dock parent;

boolean finishJob = false;
ArrayList <Job> jobs ;
boolean isDocked = false;
boolean doingJob = false;
boolean isWaiting = true;
boolean hasWorker = false;

public Ship(Scanner in) {
		super(in);
		if(in.hasNextDouble()){
			setWeight(in.nextDouble());
		}
		if(in.hasNextDouble()){
			setLength(in.nextDouble());
		}
		if(in.hasNextDouble()){
			setWidth(in.nextDouble());
		}
		if(in.hasNextDouble()){
			setDraft(in.nextDouble());
		}
		setJobs(new ArrayList<>());
	}

public void setDraft(double draft){
	this.draft = draft;
}
public double getDraft(){
	return draft;
}
public void setLength(double length){
	this.length = length;
}
public double getLength(){
	return length;
}
public void setWeight(double weight){
	this.weight = weight;
}
public double getWeight(){
	return weight;
}
public void setWidth(double width){
	this.width = width;
}
public double getWidth(){
	return width;
}
public void setJobs(ArrayList<Job>jobs) {
	this.jobs = jobs;
}
public ArrayList<Job> getJobs(){
	return jobs;
}
public void leaveDock() {
	 parent.askForNewShip();
}
boolean requestWorker(String req) {
	return parent.requestWorker(req);
}

Person p = null;
public Boolean checkAvail() {
	if(p.available) {
		return true;
	}
	return false;
}
public Person getWorker(String req) {
	p = parent.getWorker(req);

	return parent.getWorker(req);
}
//see passenger ship for explinatioon for multiple string methods

public String specificString() {
	return super.toString()+
			"\nWeight: " + getWeight() + 
			"\nLength: " + getLength() + 
			"\nWidth: " + getWidth() + 
			"\nDraft: " + getDraft() + 
			"\nJobs: N/A";
}
public String toString(){
	return super.toString();
	
}

public void setParent(Dock dock) {
	// TODO Auto-generated method stub
	parent = dock;
}


}
