package project1;
/*
 * SeaPort.java
 * 4/27/19
 * Brandon Tennyson
 * 
 * This class is a big parent class be
 * cause it hold all other values 
 * such as ship, dock, person,etc
 *  and stores data for them in arraylists
 * 
 */
import java.util.ArrayList;
import java.util.Scanner;
import java.util.Collections;
import java.util.Comparator;

public class SeaPort extends Thing {
// these arraylists hold what is in the seaport
ArrayList <Dock>docks;
ArrayList <Ship>queue;
ArrayList <Ship>ships;
ArrayList <Person>persons;
//scanner constructor
public SeaPort(Scanner in) {
	super(in);
	setDocks(new ArrayList<Dock>());
	setQueue(new ArrayList<Ship>());
	setShips(new ArrayList<Ship>());
	setPersons(new ArrayList<Person>());
}
//----------setters/getters----------v
public void setDocks(ArrayList<Dock> ports){
	this.docks = ports;
}
public ArrayList<Dock> getDocks(){
	return docks;
}
public void setQueue(ArrayList<Ship> queue){
	this.queue = queue;
}
public ArrayList<Ship> getQueue(){
	return queue;
}
public void setShips(ArrayList<Ship> ships){
	this.ships = ships;
}
public ArrayList<Ship> getShips(){
	return ships;
}
public void setPersons(ArrayList<Person> persons){
	this.persons = persons;
}
public ArrayList<Person> getPersons(){
	return persons;
}
//----------setters/getters----------^

public boolean requestWorker(String req){
		for(Person p : persons) {
			if(p.correctSkill(req)) {
				return true;		
		}
	}
	return false;
}
public Person getWorker(String req) {
		for(Person p : persons) {
			if(p.correctSkill(req)) {
				return p;
			}		
		}
		return null;
}


public boolean isExist() {
	if(super.getName().equals("<string>")) {
		return false;
	}
	return true;
}

//rubric provided toString - slightly modified
public String toString () {
	 String st = "\n\nSeaPort: " + super.toString() + "\n\n";
	 for (Dock md: getDocks())
		 st += "\n" + md;
	 
	 	st += "\n\n --- List of all ships in que:";
	 
	 for (Ship ms: getQueue() )
		 st += "\n > " + ms.toString();
	 
	 	st += "\n\n --- List of all ships:";
	 
	 for (Ship ms: getShips())
		 if(ms.index != 0)// this takes care of any empty ships
		 st += "\n > " + ms.toString();
	 
	 	st += "\n\n --- List of all persons:";
	 
	 for (Person mp: getPersons())
		 st += "\n > " + mp;
	 if(super.getName().equals("<string>")) {
		 return "";
	 }
	 return st;
	 }
public void sortByWeight() {

	Collections.sort(queue, new Comparator <Ship>() {

		@Override
		public int compare(Ship arg0, Ship arg1) {
			// TODO Auto-generated method stub
			return (arg0.getWeight() < arg1.getWeight() ? -1: (arg0.getWeight() == arg1.getWeight() ? 0:1));
		}
		
	});
} public void sortByLength() {

	Collections.sort(queue, new Comparator <Ship>() {

		@Override
		public int compare(Ship arg0, Ship arg1) {
			// TODO Auto-generated method stub
			return (arg0.getLength() < arg1.getLength() ? -1: (arg0.getLength() == arg1.getLength() ? 0:1));
		}
		
	});
}public void sortByWidth() {

	Collections.sort(queue, new Comparator <Ship>() {

		@Override
		public int compare(Ship arg0, Ship arg1) {
			// TODO Auto-generated method stub
			return (arg0.getWidth() < arg1.getWidth() ? -1: (arg0.getWidth() == arg1.getWidth() ? 0:1));
		}
		
	});
}public void sortByDraft() {

	Collections.sort(queue, new Comparator <Ship>() {

		@Override
		public int compare(Ship arg0, Ship arg1) {
			// TODO Auto-generated method stub
			return (arg0.getDraft() < arg1.getDraft() ? -1: (arg0.getDraft() == arg1.getDraft() ? 0:1));
		}
		
	});
}
}
