package project1;

/*
 * PassengerShip.java
 * 3/30/19
 * Brandon Tennyson
 * 
 * this is the passengerShip class where it
 * hold specific values to passenger ship
 * 
 * 
 */
import java.util.Scanner;

public class PassengerShip extends Ship{
//variables
int numberOfOccupiedRooms;
int numberOfPassengers;
int numberOfRooms;
//scanner constructor
public PassengerShip(Scanner in) {
	super(in);
	if(in.hasNextInt()){
		setNumberOfPassengers(in.nextInt());
	}
	if(in.hasNextInt()){
		setNumberOfRooms(in.nextInt());
	}
	if(in.hasNextInt()){
		setNumberOfOccupiedRooms(in.nextInt());
	}
}

public void setNumberOfOccupiedRooms(int numberOfOccupiedRooms){
	this.numberOfOccupiedRooms = numberOfOccupiedRooms;
}
public int getNumberOfOccupiedRooms(){
	return numberOfOccupiedRooms;
}
public void setNumberOfPassengers(int numberOfPassengers){
	this.numberOfPassengers = numberOfPassengers;
}
public int getNumberOfPassengers(){
	return numberOfPassengers;
}	
public void setNumberOfRooms(int numberOfRooms){
	this.numberOfRooms = numberOfRooms;
}
public int getNumberOfRooms(){
	return numberOfRooms;
}
// i used 2 toString methods to be used in different places where i did not want to present too much data in some searches like seaPort
public String specificString() {
	return "Passenger Ship: " + super.specificString()+
			"\n#passengers: " + getNumberOfPassengers() +
			"\n#rooms: " + getNumberOfRooms() +
			"\n#occupued Rooms: " + getNumberOfOccupiedRooms();
}
public String toString(){
	return "Passenger Ship: " + super.toString() ; 
}
}
