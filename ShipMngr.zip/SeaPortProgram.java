package project1;

/*
 * SeaPortProgram.java
 * 4/27/19
 * Brandon Tennyson
 * 
 * this class is where the GUI is created 
 * and gives a work of art to be viewed by the user 
 * this class also handles the users actions such as
 * button presses and provides a satisfying output
 * 
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.tree.DefaultMutableTreeNode;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

@SuppressWarnings("serial")
public class SeaPortProgram extends JFrame {
	public static void main(String[] args) {// main method to launch the program
		@SuppressWarnings("unused")
		SeaPortProgram i = new SeaPortProgram();
	}

	World world = new World();
	Scanner in;// i use scanner in because it is short and it has been my goto name for it
				// since i started using it... in case you where wondering... because begenners
				// use in.getNextInt()..... yeah

//initilise components
	JFrame frame = new JFrame();
	JLabel searchLabel = new JLabel("Search for: ");
	JLabel sortLabel = new JLabel("Sort Ships in Queue by: ");
	JPanel jobs = new JPanel();
	JTree tree;
	JScrollPane treesp;
	JButton searchButton = new JButton("Search");
	JButton fileButton = new JButton("File");
	JButton sortButton = new JButton("Sort");
	JTextField searchBar = new JTextField(10);// sets size for the textfield
	JComboBox<String> searchBox = new JComboBox<String>(new String[] { "Name", "Index", "Skill" });// sets names for
																									// combo box options
	JComboBox<String> sortBox = new JComboBox<String>(new String[] { "Weight", "Length", "Width", "Draft" });// sets
																												// names
																												// for
																												// combo
																												// box
																												// options
	JTextArea output = new JTextArea(30, 70);
	JScrollPane scroll = new JScrollPane(output);// put the textarea in the scroll

	DefaultMutableTreeNode top;

	public SeaPortProgram() {
		frame.setLayout(getLayout());
		top = new DefaultMutableTreeNode("World");
		// createNodes(top);
		tree = new JTree(top);
		treesp = new JScrollPane(tree);
		JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scroll, treesp);
		split.setDividerLocation(350);

		output.setFont(new java.awt.Font("Monospaced", 0, 12));// rubric required font
		JPanel p1 = new JPanel();// i prefer to use jpanels so that i may add to them and insert them into my
									// frame easily
		JPanel p2 = new JPanel();
		JPanel p3 = new JPanel();

		frame.setSize(650, 700);// size of window

		output.setLineWrap(true);// ooh gettin fancy
		output.setBorder(new LineBorder(Color.BLACK));// gotta show it off
		scroll.getViewport().setBackground(Color.WHITE);// adding a nice contrast to this work of art lol
		// start adding elements into panels
		p1.add(fileButton);
		p1.add(searchLabel);
		p1.add(searchBar);
		p1.add(searchBox);
		p1.add(searchButton);

		p2.add(sortLabel);
		p2.add(sortBox);
		p2.add(sortButton);
		p3.add(p1, BorderLayout.NORTH);
		p3.add(p2, BorderLayout.CENTER);
		p3.add(split, BorderLayout.SOUTH);
		frame.add(p3);// add into frame

		frame.setVisible(true);// see my masterpiece
		fileButton.addActionListener(new java.awt.event.ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				getFile(arg0);// calls the method where you find the file

			}
		});
		searchButton.addActionListener(new java.awt.event.ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				search();// calls the method where you search
			}
		});
		sortButton.addActionListener(new java.awt.event.ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				sort();// calls the method where you sort
			}
		});
	}

	// this got tricky but its not that complicated
	private void initTree(DefaultMutableTreeNode top) {
		createNodes(top);

	}

	private DefaultMutableTreeNode createThingNode(Thing thing) {
		return new DefaultMutableTreeNode(thing.getIndex() + " " + thing.getName());
	}

	private void createNodes(DefaultMutableTreeNode top) {

		DefaultMutableTreeNode portNode;

		for (SeaPort seaPort : world.seaPorts.values()) {

			portNode = createThingNode(seaPort);
			DefaultMutableTreeNode node = new DefaultMutableTreeNode("Docks");
			for (Dock dock : seaPort.docks) {
				DefaultMutableTreeNode dockNode = createThingNode(dock);
				if (dock.getShip() != null) {
					DefaultMutableTreeNode shipNode = createThingNode(dock.getShip());
					for (Job job : dock.getShip().jobs) {
						shipNode.add(createThingNode(job));
					}
					dockNode.add(shipNode);
				}
				node.add(dockNode);
				portNode.add(node);
			}
			node = new DefaultMutableTreeNode("Ships in Que");
			for (Ship ship : seaPort.queue) {
				DefaultMutableTreeNode shipNode = createThingNode(ship);
				for (Job job : ship.jobs) {
					shipNode.add(createThingNode(job));
				}
				node.add(shipNode);
			}
			portNode.add(node);
			node = new DefaultMutableTreeNode("All Ships");
			for (Ship ship : seaPort.ships) {
				DefaultMutableTreeNode shipNode = createThingNode(ship);
				for (Job job : ship.jobs) {
					shipNode.add(createThingNode(job));
				}
				node.add(shipNode);
			}
			portNode.add(node);
			node = new DefaultMutableTreeNode("People");
			for (Person person : seaPort.persons) {
				DefaultMutableTreeNode personNode = createThingNode(person);
				node.add(personNode);
			}
			portNode.add(node);
			top.add(portNode);
		}
	}

	public void getFile(ActionEvent evt) {
		FileReader read;
		FileNameExtensionFilter filter;
		int selection;
		JFileChooser file = new JFileChooser("."); // thx rubric ^.^
		filter = new FileNameExtensionFilter("TEXT Files", "txt", "text");// gotta be picky
		file.setFileFilter(filter);
		file.setCurrentDirectory(new java.io.File("C:/Users/BrandonTennyson/Desktop")); // this was just for ease but i
																						// see that it will still run
																						// even if this location does
																						// not exist
		file.setDialogTitle("select file");// give a name to the window
		selection = file.showOpenDialog(new JFrame());
		if (selection == JFileChooser.APPROVE_OPTION) {// this is what is needed in order for the whole thing to work
			try {
				read = new FileReader(file.getSelectedFile());
				in = new Scanner(read);
				String st = "";
				while (in.hasNextLine()) { // this is where i used the scanner to take in each line one by one into the
											// process class of world and went from there
					st += in.nextLine() + "\n";

					// world.process(in.nextLine());
					// output.setText(world.toString());//this shows the content of the file to the
					// person so they know everytrhing is in there
				}
				world.setPanel(jobs);

				world.process(st);

				output.setText(world.toString());
				initTree(top);

				world.showFrame();
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	// this method is new and it only calls methods in the world class to display
	// the correct sorted ships
	public void sort() {
		if (world == null || in == null) {
			JOptionPane.showMessageDialog(frame, "cannot find world becausey you did not build it yet", "world error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		String selection = (String) sortBox.getSelectedItem();
		switch (selection) {
		case "Weight":
			output.setText(world.sortWeight());
			break;
		case "Length":
			output.setText(world.sortLength());
			break;
		case "Width":
			output.setText(world.sortWidth());
			break;
		case "Draft":
			output.setText(world.sortDraft());
			break;
		}

	}

	// search method was easy via the methods in world
	public void search() {

		if (world == null || in == null) {
			JOptionPane.showMessageDialog(frame, "cannot find world becausey you did not build it yet", "world error",
					JOptionPane.ERROR_MESSAGE);
			return;
		}
		String selection = (String) searchBox.getSelectedItem();
		switch (selection) {
		case "Name":
			String stringName = world.searchName(searchBar.getText());
			if (stringName == null) {
				JOptionPane.showMessageDialog(frame, "could not find name.", "not Found", JOptionPane.ERROR_MESSAGE);
				return;
			}
			output.setText(stringName);
			break;
		case "Index":
			String stringIndex;
			if (!isNum(searchBar.getText()) || world.searchIndex(Integer.parseInt(searchBar.getText())) == null) {
				JOptionPane.showMessageDialog(frame, "could not find index.", "not Found", JOptionPane.ERROR_MESSAGE);
				return;
			}
			stringIndex = world.searchIndex(Integer.parseInt(searchBar.getText())).toString();
			output.setText(stringIndex);
			break;
		case "Skill":
			String stringSkill = world.searchSkill(searchBar.getText());
			if (stringSkill == null) {
				JOptionPane.showMessageDialog(frame, "could not find skill.", "not Found", JOptionPane.ERROR_MESSAGE);
				return;
			}
			output.setText(stringSkill);
			break;
		}

	}

	public boolean isNum(String s) {
		try {
			Integer.parseInt(s);
			return true;
		} catch (NumberFormatException e) {
			return false;
		}
	}

}
