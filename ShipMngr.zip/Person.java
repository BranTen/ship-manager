package project1;
/*
 * Person.java
 * 3/30/19
 * Brandon Tennyson
 * 
 * People are created here.... that sounds wrong 
 * but they are! and they have skills
 * 
 */
import java.util.Scanner;

public class Person extends Thing{

String skill;
//scanner constructor
public Person(Scanner in) {
		super(in);
		if(in.hasNext()){
			setSkill(in.next());
		}else{
			setSkill("none");
		}
}

public void setSkill(String skill){
	this.skill = skill;
}
public String getSkill(){
	return skill;
}
public boolean correctSkill(String req) {
	return req.matches(getSkill());
}
boolean available = true;

public String toString(){
	return "Person: " +super.toString() + " skill is " + getSkill();
}
}
