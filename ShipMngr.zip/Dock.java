package project1;

import java.util.HashMap;
/*
 * Dock.java
 * 4/27/19
 * Brandon Tennyson
 * 
 * this is the dock class where the dock is created as well as starts the jobs that need to be done to the ship
 *  and alternates between ships to do jobs for
 * 
 */
import java.util.Scanner;

public class Dock extends Thing {

	Ship ship;

	public Dock(Scanner in) {
		super(in);
	}

	public void setShip(Ship ship) {
		ship.setParent(this);// this is so that the sxhip knows also whos parent it is
		this.ship = ship;
		//while(ship.isWaiting) {
		ship.isDocked = true;
		
		ship.doingJob = true;// needed in order to start job
		//}
	}

	public Ship getShip() {
		return ship;
	}

	SeaPort parent; // holds the parent of the dock

	public void dockParent(HashMap<Integer, SeaPort> seaPorts) {
		// TODO Auto-generated method stub
		for (SeaPort s : seaPorts.values()) {
			if (s.getIndex() == this.getParent()) {
				parent = s;
			}
		}
	}

	static int count = 0;// static because this variable is used over many instances of docks

	public void askForNewShip() {
		this.ship = null;//take out old ship
		Ship ship = null;//set up new ship

		if (count < parent.getQueue().size()) {// grab the next ship in que
			ship = parent.queue.get(count);
			setShip(ship);
			this.ship.doingJob = true;//start job on new ship
			count++;
		}
	}

	public String toString() {
		String s = "Dock: " + super.toString() + "\n";
		if (getShip() == null) {
			s = s + "N/A";
		} else {
			s = s + "  Ship: " + getShip().toString();
		}
		return s;
	}

	public boolean requestWorker(String req) {
		// TODO Auto-generated method stub
		return parent.requestWorker(req);
	}

	public Person getWorker(String req) {
		// TODO Auto-generated method stub
		return parent.getWorker(req);
	}



}
