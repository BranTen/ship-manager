package project1;
/*
 * Job.java
 * 4/27/19
 * Brandon Tennyson
 * 
 *this class is where the job is managed and actually done. it changes the status as well as helps start the next job
 * 
 */
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class Job extends Thing implements Runnable { //initilises elements 
	JPanel panel = new JPanel();
	int index;

	String jobName = "";
	JProgressBar bar = new JProgressBar();
	boolean stop = true, noKillFlag = true;
	JButton stopButton = new JButton("Stop");
	JButton cancelButton = new JButton("Cancel");

	Status status = Status.WAITING;
	Ship parent;

	enum Status {
		RUNNING, SUSPENDED, WAITING, DONE
	};

	double duration;

	public Job(Scanner in, JPanel panel, HashMap<Integer, Ship> ships) {// constructor creates gui, sets variables and adds action listeners
		super(in);
		
		parent = ships.get(super.getParent());
		panel.add(new JLabel(parent.getName()));
		panel.add(new JLabel("(" + name + ")"));
		panel.add(bar);
		panel.add(stopButton);
		panel.add(cancelButton);
		

		if (in.hasNextDouble()) {
			setDuration(in.nextDouble());
		}
		setPanel(panel);

		new Thread(this).start();

		stopButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				toggleGoFlag();
			}
		});
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setKillFlag();
			}
		});
	}
//setters and gettersvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
	public void setKillFlag() {
		noKillFlag = false;
		cancelButton.setBackground(Color.red);
	}

	public void setPanel(JPanel panel) {
		this.panel = panel;
	}

	public JPanel getPanel() {
		return panel;
	}

	public void setDuration(double duration) {
		this.duration = duration;
	}

	public double getDuration() {
		return duration;
	}
//^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
	public String toString() {
		return "Duration: " + duration;
	}

	private void waitFor(long l) {// this method specifically used for timing the progress bars
		try {
			Thread.sleep(l);
		} catch (InterruptedException e) {
		}
	}
	public void run() {// this method is the meat of this class and makes the progress bars stop and go accordingly

		// TODO Auto-generated method stub
		long time = System.currentTimeMillis();
		long startTime = time;
		long stopTime = (long) (time + 1000 * duration);
		double duration = stopTime - time;
		boolean canStart = false;
		
while(!parent.isDocked) {//continue waiting until docked
				showStatus(Status.WAITING);	
		}
		parent.getWorker(name);//after docked then find a worker

		
		while(!parent.checkAvail()) {// until worker is available wait
			showStatus(Status.WAITING);	
	}


				parent.p.available = false;//once worker is available then have the worker no longer be available
		while (time < stopTime && noKillFlag) {//if the suration of progress bar is less than the time to stop, continue
			waitFor(100);
			if (stop) {
				showStatus(Status.RUNNING);
				time += 100;
				bar.setValue((int) (((time - startTime) / duration) * 100));// simits the time
			} else {
				showStatus(Status.SUSPENDED);// if clicked then it will pause 
			}
		}
		bar.setValue(100);
		showStatus(Status.DONE);//finished
		parent.finishJob = true;// job is now finished
		parent.p.available = true;
		parent.leaveDock();// this departs the current ship as well as adds a new one to the dock to be worked on

	}

	void showStatus(Status st) {// this is just good to have to make it easier
		status = st;
		switch (status) {
		case RUNNING:
			stopButton.setBackground(Color.green);
			stopButton.setText("Running");
			break;
		case SUSPENDED:
			stopButton.setBackground(Color.yellow);
			stopButton.setText("Suspended");
			break;
		case WAITING:
			stopButton.setBackground(Color.orange);
			stopButton.setText("Waiting turn");
			break;
		case DONE:
			stopButton.setBackground(Color.red);
			stopButton.setText("Done");
			break;
		} // end switch on status
	}

	public void toggleGoFlag() {//self explanitory
		stop = !stop;
	}
}
