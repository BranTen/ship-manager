package project1;
/*
 * Thing.java
 * 4/27/19
 * Brandon Tennyson
 * 
 * this is the thing class if its a thing then its here, 
 * thing is the overall parent of all object in this class 
 * and every - thing lol has an index, name, and parent
 */
import java.util.Scanner;

public class Thing implements Comparable <Thing>{
int index;
String name;
int parent;
public Thing() {
	
}
	public Thing (Scanner in){
		if(in.hasNext()){
			setName(in.next());
		}
		if(in.hasNextInt()){
			setIndex(in.nextInt());
		}
		if(in.hasNextInt()){
			setParent(in.nextInt());
		}
	}
	//method exists because thing implements comparable
	public int compareTo(Thing arg) {

		 if(arg.getIndex() == getIndex() && 
			arg.getName().equals(getName()) &&
			arg.getParent() == getParent()){
			return 1;
		}		
		return 0;
	}
	//----------setters/getters----------v
	public void setIndex(int index){
		this.index = index;
	}
	public int getIndex(){
		return index;
	}
	public void setName(String name){
		this.name = name;
	}
	public String getName(){
		return name;
	}
	public void setParent(int parent){
		this.parent = parent;
	}
	public int getParent(){
		return parent;
	}
	//----------setters/getters----------^
	public String toString(){
		return getName() + " " + getIndex();
	}
}
