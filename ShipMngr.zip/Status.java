package project1;

public enum Status {
	SUSPENDED

}
