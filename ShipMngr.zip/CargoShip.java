package project1;

/*
 * CargoShip.java
 * 3/30/19
 * Brandon Tennyson
 * 
 * this is where the cargo ship objects are created, 
 * it holds specific values to cargoship
 * 
 */
import java.util.Scanner;

public class CargoShip extends Ship{

	double cargoValue;
	double cargoVolume;
	double cargoWeight;
	
	public CargoShip(Scanner in) {
		super(in);
		if(in.hasNextDouble()){
			setCargoWeight(in.nextDouble());
		}
		if(in.hasNextDouble()){
			setCargoVolume(in.nextDouble());
		}
		if(in.hasNextDouble()){
			setCargoValue(in.nextDouble());
		}
	}
	
	public void setCargoValue(double cargoValue){
		this.cargoValue = cargoValue;
	}
	public double getCargoValue(){
		return cargoValue;
	}
	public void setCargoVolume(double cargoVolume){
		this.cargoVolume = cargoVolume;
	}
	public double getCargoVolume(){
		return cargoVolume;
	}	
	public void setCargoWeight(double cargoWeight){
		this.cargoWeight = cargoWeight;
	}
	public double getCargoWeight(){
		return cargoWeight;
	}
	//see passenger ship for explinatioon for multiple string methods
	public String specificString() {
		return "CargoShip: " + super.specificString()+
				"\nCargo Weight: " + getCargoWeight() +
				"\nCargoVolume: " + getCargoVolume() +
				"\nCargo Value: " + getCargoValue();
	}
	public String toString(){
		return "CargoShip: " + super.toString() ;
	}
}
